package com.shimy.judicialagenda;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.OutputStream;
import org.json.JSONObject;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 11;
    private WebView web;
    private WebView printWeb;
    private ValueCallback<Uri[]> chooserCb;
    private Uri camUri;
    private String pendingPair = null;
    private static final int REQ_QR = 0x0000c0de;
    private final java.util.concurrent.ExecutorService ocrPool = java.util.concurrent.Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#0d2238"));
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);

        handlePairIntent(getIntent());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                flushPair();
            }
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("ocr.local".equals(u.getHost())) {
                    java.util.Map<String, String> h = new java.util.HashMap<>();
                    h.put("Access-Control-Allow-Origin", "*");
                    try {
                        String p = u.getPath() == null ? "" : u.getPath();
                        if (p.startsWith("/")) p = p.substring(1);
                        if (p.contains("..")) throw new Exception("bad");
                        java.io.InputStream in = getAssets().open("ocr/" + p);
                        String mt = p.endsWith(".js") ? "application/javascript" : "application/octet-stream";
                        return new WebResourceResponse(mt, null, 200, "OK", h, in);
                    } catch (Exception e) {
                        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h, new java.io.ByteArrayInputStream(new byte[0]));
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                if ("file".equals(scheme) || "data".equals(scheme) || "blob".equals(scheme) || "about".equals(scheme)) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl()));
                } catch (Exception ignored) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (chooserCb != null) chooserCb.onReceiveValue(null);
                chooserCb = cb;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                Intent chooser = Intent.createChooser(pick, "اختر ملفاً أو التقط صورة");
                try {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Images.Media.DISPLAY_NAME, "agenda_" + System.currentTimeMillis() + ".jpg");
                    v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                    Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cam.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
                } catch (Exception e) {
                    camUri = null;
                }
                try {
                    startActivityForResult(chooser, REQ_FILE);
                } catch (Exception e) {
                    chooserCb = null;
                    return false;
                }
                return true;
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private void handlePairIntent(Intent it) {
        try {
            if (it == null || it.getData() == null) return;
            Uri u = it.getData();
            if (!"judicialagenda".equals(u.getScheme())) return;
            String h = u.getQueryParameter("host"), p = u.getQueryParameter("pin");
            if (h == null || p == null) return;
            pendingPair = "window.__pair&&window.__pair(" + JSONObject.quote(h) + "," + JSONObject.quote(p) + ")";
        } catch (Exception ignored) { }
    }

    private void flushPair() {
        if (pendingPair == null || web == null) return;
        final String js = pendingPair;
        pendingPair = null;
        web.postDelayed(() -> web.evaluateJavascript(js, null), 800);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handlePairIntent(intent);
        flushPair();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_QR) {
            String r = (resultCode == RESULT_OK && data != null) ? data.getStringExtra("SCAN_RESULT") : null;
            if (r != null && r.length() > 0) {
                final String js = "window.__qrResult&&window.__qrResult(" + JSONObject.quote(r) + ")";
                web.evaluateJavascript(js, null);
            }
            return;
        }
        if (requestCode != REQ_FILE || chooserCb == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getClipData() != null) {
                ClipData cd = data.getClipData();
                result = new Uri[cd.getItemCount()];
                for (int i = 0; i < cd.getItemCount(); i++) result[i] = cd.getItemAt(i).getUri();
            } else if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            } else if (camUri != null) {
                result = new Uri[]{camUri};
            }
        }
        chooserCb.onReceiveValue(result);
        chooserCb = null;
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){return window.__back?window.__back():false})()", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    /** استخراج النص محلياً بمحرك Tesseract الأصلي (بدون إنترنت وبدون كمبيوتر) */
    private String[] nativeOcr(String b64, String langs) throws Exception {
        File base = new File(getFilesDir(), "tess");
        File td = new File(base, "tessdata");
        td.mkdirs();
        for (String l : langs.split("\\+")) {
            File f = new File(td, l + ".traineddata");
            if (!f.exists() || f.length() < 100000) {
                java.io.InputStream in = new java.util.zip.GZIPInputStream(getAssets().open("ocr/lang/" + l + ".traineddata.gz"));
                OutputStream out = new java.io.FileOutputStream(f);
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
            }
        }
        byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
        android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        if (bmp == null) throw new Exception("تعذر قراءة الصورة");
        Class<?> c = Class.forName("com.googlecode.tesseract.android.TessBaseAPI");
        Object api = c.getConstructor().newInstance();
        try {
            Boolean ok = (Boolean) c.getMethod("init", String.class, String.class).invoke(api, base.getAbsolutePath(), langs);
            if (ok == null || !ok) throw new Exception("تعذر تحميل بيانات اللغة");
            c.getMethod("setImage", android.graphics.Bitmap.class).invoke(api, bmp);
            String text = (String) c.getMethod("getUTF8Text").invoke(api);
            String hocr = "";
            try {
                Object h = c.getMethod("getHOCRText", int.class).invoke(api, 0);
                if (h != null) hocr = h.toString();
            } catch (Throwable ignored) { }
            return new String[]{text == null ? "" : text.trim(), hocr};
        } finally {
            try { c.getMethod("recycle").invoke(api); } catch (Throwable ignored) { }
        }
    }

    /** الجسر بين الصفحة والتطبيق: حفظ الملفات والطباعة */
    public class Bridge {
        @JavascriptInterface
        public boolean hasOcr() {
            try {
                Class.forName("com.googlecode.tesseract.android.TessBaseAPI");
                return true;
            } catch (Throwable e) {
                return false;
            }
        }

        @JavascriptInterface
        public void ocr(final String id, final String b64, final String langs) {
            ocrPool.execute(() -> {
                String text = "", err = "", hocr = "";
                try {
                    String[] r = nativeOcr(b64, langs);
                    text = r[0];
                    hocr = r[1];
                } catch (Throwable e) {
                    Throwable x = e.getCause() != null ? e.getCause() : e;
                    err = x.getClass().getSimpleName() + ": " + x.getMessage();
                }
                final String js = "window.__ocrDone&&window.__ocrDone(" + JSONObject.quote(id) + "," + JSONObject.quote(text) + "," + JSONObject.quote(err) + "," + JSONObject.quote(hocr) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            });
        }

        @JavascriptInterface
        public void scanQr() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent("com.google.zxing.client.android.SCAN");
                    i.setClassName(getPackageName(), "com.journeyapps.barcodescanner.CaptureActivity");
                    i.putExtra("SCAN_FORMATS", "QR_CODE");
                    i.putExtra("PROMPT_MESSAGE", "وجّه الكاميرا نحو QR على شاشة الكمبيوتر");
                    i.putExtra("BEEP_ENABLED", false);
                    startActivityForResult(i, REQ_QR);
                } catch (Throwable e) {
                    web.evaluateJavascript("toast('ماسح QR غير متاح — امسح الصورة بكاميرا الهاتف العادية')", null);
                }
            });
        }

        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/JudicialAgenda");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = getContentResolver().openOutputStream(uri);
                os.write(bytes);
                os.close();
                toast("تم الحفظ في: التنزيلات/JudicialAgenda/" + name);
            } catch (Exception e) {
                toast("تعذر حفظ الملف");
            }
        }

        @JavascriptInterface
        public void shareFile(final String name, final String mime, final String base64) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/JudicialAgenda");
                final Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = getContentResolver().openOutputStream(uri);
                os.write(bytes);
                os.close();
                final String type = (mime == null || mime.length() == 0) ? "*/*" : mime;
                runOnUiThread(() -> {
                    try {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(type);
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "مشاركة"));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "تعذرت المشاركة", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                toast("تعذرت المشاركة");
            }
        }

        @JavascriptInterface
        public void printHtml(final String title, final String html, final boolean landscape) {
            runOnUiThread(() -> {
                printWeb = new WebView(MainActivity.this);
                printWeb.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        PrintAttributes.MediaSize size = landscape
                                ? PrintAttributes.MediaSize.ISO_A4.asLandscape()
                                : PrintAttributes.MediaSize.ISO_A4;
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(size)
                                .setResolution(new PrintAttributes.Resolution("res", "res", 300, 300))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        pm.print(title, view.createPrintDocumentAdapter(title), attrs);
                    }
                });
                printWeb.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }
    }
}
